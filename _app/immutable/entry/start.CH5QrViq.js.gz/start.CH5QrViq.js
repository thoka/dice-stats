import{a as t}from"../chunks/CBEECR_A.js";export{t as start};
